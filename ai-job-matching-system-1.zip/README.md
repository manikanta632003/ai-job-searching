# AI Job Matching System

This is an AI-powered job matching system that matches students to relevant job roles based on their programming skills.

## Features
- Add students with skills
- Add job listings with required skills
- Match students to jobs using AI (TF-IDF & Cosine Similarity)

## Project Structure
- `backend/` - Flask API
- `frontend/` - React UI components
- `data/` - Excel dataset

## How to Run

### Backend
```bash
cd backend
pip install flask flask-cors scikit-learn
python app.py
```

### Frontend
Use React to create forms and send API requests.

## Dataset
The dataset is in the `data/Job_Matching_Dataset.xlsx` file.
